(function (root) {
  'use strict';
  const C = root.MoocCore;
  const defaults = {
    question: '.TiMu, .question-item, .questionLi, .mark_item, [data-question-id]',
    stem: '[data-role="question-stem"], .Zy_TItle, .mark_name, .question-title, .questionTitle',
    option: '[data-role="question-option"], .Zy_ulTop li, .Zy_ulBottom li, .answerList li, .answer-list li, .option-item',
    selectedOption: '[aria-checked="true"], [aria-selected="true"], .check_answer, .checkAnswer, .checked, .selected, .active',
    submit: '#submitWork, #submitButton, .submitBtn, .submit-btn, [data-role="quiz-submit"], button, input[type="button"], a',
    chapter: '.posCatalog_name, .catalog_name, .ncells, [data-chapterid], [data-knowledgeid], [data-role="chapter"]',
    currentChapter: '[aria-current="page"], .posCatalog_active, .currents, .catalog-current, [data-current="true"]',
    completedChapter: '.icon-wancheng, .icon_wancheng, .posCatalog_complete, .catalog_completed, [data-state="completed"], [data-status="completed"]',
    task: '.ans-attach-ct, .ans-task, [data-role="mooc-task"]',
    completedTask: '.ans-job-finished, [data-task-state="complete"], [data-state="completed"]',
    taskTab: '.prev_ul li, .prev_list > ul > li, .tabtags li, .tabtags a, .ans-tab li, .ans-tab a, [data-role="task-tab"]'
  };
  let selectors = {...defaults}, nextId = 0, backgroundPlayback = true;
  const ids = new WeakMap(), nodes = new Map(), pendingPlays = new WeakMap();
  function id(el) {
    if (!ids.has(el)) { const key = `n${++nextId}`; ids.set(el, key); nodes.set(key, el); }
    return ids.get(el);
  }
  function get(key) { const el = nodes.get(key); if (!el?.isConnected) throw new Error('页面元素已变化，请重新检查'); return el; }
  function query(scope, selector) { return Array.from(scope.querySelectorAll(selector)); }
  function visible(el) {
    if (!el?.isConnected || el.closest('#mooc-helper-root')) return false;
    if (el.closest('[hidden]')) return false;
    const css = getComputedStyle(el);
    return css.display !== 'none' && css.visibility !== 'hidden' && css.visibility !== 'collapse' && el.getClientRects().length > 0;
  }
  function frameVisible() {
    let w = window;
    try { while (w !== w.top) { const frame = w.frameElement; if (!frame) break; if (!visible(frame)) return false; w = w.parent; } }
    catch { /* Cross-origin parents are checked by the coordinator's ambiguity guards. */ }
    return backgroundPlayback || document.visibilityState === 'visible';
  }
  function text(el) { return (el?.innerText ?? el?.textContent ?? '').trim(); }
  function quizText(el) {
    if (root.MoocFontDecoder) return root.MoocFontDecoder.read(el);
    if (el && (el.closest('.font-cxsecret') || el.querySelector('.font-cxsecret'))) throw new Error('检测到混淆字体，请重新加载扩展并刷新课程页面');
    return text(el);
  }
  function ownOrChild(el, selector) { return el.matches(selector) || Boolean(el.querySelector(selector)); }
  function completion(el) {
    if (!el) return null;
    if (ownOrChild(el, selectors.completedTask)) return true;
    const statuses = [el, ...query(el, '.ans-job-icon, .task-status, [data-task-state], [data-state], .ans-job-title')];
    if (statuses.some(s => /^(已完成|已提交|完成)$/.test(text(s)))) return true;
    if (statuses.some(s => /^(待完成|未完成|进行中)$/.test(text(s)))) return false;
    if (el.querySelector('.ans-job-icon') || el.matches('.ans-job')) return false;
    return null;
  }
  function taskContainer(el) { return el.closest(selectors.task); }
  function configure(custom = {}) {
    const changed = {...defaults};
    for (const [key, value] of Object.entries(custom)) {
      if (!Object.hasOwn(defaults, key) || typeof value !== 'string' || !value.trim()) throw new Error(`无效的选择器设置：${key}`);
      document.querySelector(value); // Validate CSS syntax, never evaluate code.
      changed[key] = value;
    }
    selectors = changed;
  }
  function topRoots(list) { return list.filter(el => !list.some(other => other !== el && other.contains(el))); }
  function optionSelected(el) {
    const input = el.matches('input') ? el : el.querySelector('input[type="radio"], input[type="checkbox"]');
    if (input) return input.checked;
    return ownOrChild(el, selectors.selectedOption);
  }
  function optionText(el) {
    const content = el.querySelector('[data-role="option-text"], .option-content, .answer_p, .option-text');
    const value = content ? quizText(content) : '';
    return (value || quizText(el)).replace(/^\s*[A-H](?:\s*[、.．:：]\s*|\s+)/, '').trim();
  }
  function readQuestions() {
    root.MoocFontDecoder?.begin();
    const roots = topRoots(query(document, selectors.question).filter(visible));
    return roots.map(el => {
      const title = el.querySelector(selectors.stem);
      let titleText = quizText(title).normalize('NFKC');
      const type = (titleText.match(/单选题|多选题|判断题/) || quizText(el).match(/单选题|多选题|判断题/) || [])[0] || el.dataset.questionType || '';
      const stem = titleText.replace(/^\s*\d+\s*[.、．]?\s*/, '')
        .replace(/^\s*\(\s*(单选题|多选题|判断题)\s*(?:,\s*\d+(?:\.\d+)?\s*分)?\s*\)\s*/, '')
        .replace(/^\s*[【\[]?(单选题|多选题|判断题)[】\]]?\s*/, '')
        .replace(/\s*\(\s*\d+(?:\.\d+)?\s*分\s*\)\s*$/, '').trim();
      let options = query(el, selectors.option).filter(visible);
      if (!options.length) options = query(el, 'label').filter(o => visible(o) && o.querySelector('input[type="radio"], input[type="checkbox"]'));
      options = topRoots(options);
      return {id: id(el), type, stem, hasImage: Boolean(el.querySelector('img, canvas, svg, math')),
        options: options.map(o => ({id: id(o), text: optionText(o), selected: optionSelected(o),
          enabled: !o.matches('[disabled], [aria-disabled="true"]') && !o.querySelector('input:disabled')}))};
    });
  }
  function readQuiz() {
    const confirmed = query(document, '.testTit_status, .testTit_status_complete, .work-status, [data-role="quiz-status"]')
      .some(el => visible(el) && /^(已完成|已提交)$/.test(text(el)));
    if (confirmed) return {id:'quiz',questions:[],expected:null,incomplete:false,submitIds:[],complete:true,signature:null};
    let questions;
    try { questions = readQuestions(); }
    catch (error) { return {id: 'quiz', questions: [], incomplete: true, complete: false, submitIds: [], fontError: error.message}; }
    if (!questions.length) return null;
    const body = text(document.body);
    const hintCount = [...body.matchAll(/[【\[](单选题|多选题|判断题)[】\]]/g)].length;
    const expected = body.match(/题量\s*[:：]\s*(\d+)/)?.[1];
    const submits = query(document, selectors.submit).filter(el => visible(el) && /^(提交|提交作业|提交答案|交卷|提交测验)$/.test(text(el) || el.value || ''));
    const status = query(document, '.task-status, .work-status, .status, .testTit_status, [data-role="quiz-status"]').filter(visible);
    const complete = status.some(el => /^(已完成|已提交)$/.test(text(el)))
      || questions.every(q => completion(taskContainer(get(q.id))) === true);
    return {id: 'quiz', questions, expected: expected ? Number(expected) : null,
      incomplete: hintCount > questions.length || (expected && Number(expected) !== questions.length),
      submitIds: submits.map(id), complete, signature: C.planQuiz(questions, null).signature};
  }
  function readVideos() {
    return query(document, 'video').filter(visible).map(v => ({id: id(v), paused: v.paused, ended: v.ended,
      rate: v.playbackRate, position: Number.isFinite(v.currentTime) ? v.currentTime : 0,
      duration: Number.isFinite(v.duration) ? v.duration : null, readyState: v.readyState,
      hasSource: Boolean(v.currentSrc || v.getAttribute('src') || v.querySelector('source[src]')),
      error: v.error?.message || null, complete: completion(taskContainer(v))}));
  }
  function readTasks() {
    const list = topRoots(query(document, selectors.task));
    return list.map(el => ({id: id(el), complete: completion(el), visible: visible(el),
      title: text(el.querySelector('.ans-job-title, .task-title')).slice(0, 80)}));
  }
  function chapterCompletion(el) {
    if (ownOrChild(el,selectors.completedChapter) || el.querySelector('[title="已完成"], [aria-label="已完成"]')) return true;
    const fields=[...query(el,'.jobUnfinishCount'),...Array.from(el.parentElement?.children || []).filter(n=>n.matches('input.jobUnfinishCount'))];
    if (fields.length && fields.every(n=>/^\d+$/.test(n.value?.trim()))) return fields.every(n=>Number(n.value)===0);
    if (query(el,'.orangeNew, .orange01').some(n=>/^\d+$/.test(text(n)) && Number(text(n))>0)) return false;
    return null;
  }
  function readEndedSurvey() {
    if (!query(document,'.ans-cmp-iconVote').some(visible) || !/问卷/.test(text(document.querySelector('#title')))) return null;
    const match=text(document.querySelector('#describe')).match(/结束时间\s*[:：]\s*(?:(\d{4})-)?(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{2})/);
    if (!match) return null;
    const year=match[1]?Number(match[1]):new Date().getFullYear(),month=Number(match[2]),day=Number(match[3]),hour=Number(match[4]),minute=Number(match[5]);
    const date=new Date(year,month-1,day,hour,minute);
    if (date.getFullYear()!==year || date.getMonth()!==month-1 || date.getDate()!==day || hour>23 || minute>59 || date.getTime()>Date.now()) return null;
    return {ended:true,title:text(document.querySelector('#title')),endTime:date.toISOString()};
  }
  function readNavigation() {
    const list = query(document, selectors.chapter).filter(visible);
    // Prefer the innermost catalog item, avoiding duplicate parent/child chapter nodes.
    const items = list.filter(el => !list.some(other => other !== el && el.contains(other)));
    const currents = query(document, selectors.currentChapter).filter(visible);
    // studentstudy replaces its content with AJAX without updating the address bar.
    const chapterId = document.querySelector('#chapterIdid')?.value
      || new URL(location.href).searchParams.get('chapterId');
    const row = el => el.closest('.posCatalog_select') || el;
    const key = el => row(el).id.match(/^cur(\d+)$/)?.[1]
      || el.dataset.chapterid || el.dataset.knowledgeid
      || row(el).dataset.chapterid || row(el).dataset.knowledgeid || '';
    let active = items.filter(el => currents.some(c => c === el || c.contains(el) || el.contains(c)));
    if (!active.length && chapterId) active = items.filter(el => {
      if (key(el) === chapterId) return true;
      const link = el.matches('a') ? el : el.querySelector('a[href]');
      try { return link && new URL(link.href, location.href).searchParams.get('chapterId') === chapterId; } catch { return false; }
    });
    const current = active.length === 1 ? active[0] : null;
    const currentIndex = current ? items.indexOf(current) : -1;
    const done = current ? chapterCompletion(row(current))===true
      || currents.some(c => c.contains(current) && ownOrChild(c, selectors.completedChapter)) : false;
    // Include collapsed catalog rows when checking the whole course, not just visible rows.
    const allItems=query(document,selectors.chapter).filter(el=>!el.closest('#mooc-helper-root'));
    const leaves=allItems.filter(el=>!allItems.some(other=>other!==el && (el.contains(other)
      || (row(el).closest('li') && row(el).closest('li').contains(row(other)) && row(el)!==row(other)))));
    const statuses=leaves.map(el=>chapterCompletion(row(el)));
    const filtered=Boolean(document.querySelector('#searchChapterListByName')?.value?.trim());
    const tabs = topRoots(query(document, selectors.taskTab).filter(el => visible(el)
      && (el.matches('.prev_ul li, .prev_list > ul > li') || /(视频|测验|测试|任务)/.test(text(el)))));
    return {chapterTitle: text(current).slice(0, 120), chapterKey: current ? key(current) || chapterId || C.hash(text(current)) : null,
      chapterComplete: current ? done : null,
      currentFound: Boolean(current), lastChapter: currentIndex >= 0 && currentIndex === items.length - 1,
      nextId: currentIndex >= 0 && items[currentIndex + 1] ? id(items[currentIndex + 1]) : null,
      catalogCount: items.length,
      catalogPending:statuses.filter(s=>s===false).length,catalogFiltered:filtered,
      allTaskPointsComplete:!filtered && statuses.length>0 && statuses.every(s=>s===true),
      tabs: tabs.map(el => ({id: id(el), title: text(el), active: ownOrChild(el, '.active, .currents, .selected, [aria-selected="true"]'), complete: completion(el)}))};
  }
  function readDialogs() {
    const dialogs = topRoots(query(document, '[role="dialog"], .maskDiv, .layui-layer-dialog, .modal, .cxDialog, .verify-wrap, .captcha').filter(visible));
    let blocker = null, confirm = null;
    for (const el of dialogs) {
      const content = text(el);
      if (/验证码|滑动验证|人脸识别|重新登录|登录已过期/.test(content)) blocker = content.slice(0, 160);
      else if (/提交|交卷/.test(content)) {
        const buttons = query(el, 'button, a, input[type="button"]').filter(b => visible(b) && /^(确定|确认|确认提交|提交)$/.test(text(b) || b.value || ''));
        if (buttons.length === 1 && !confirm) confirm = {id: id(buttons[0]), text: content.slice(0, 160)};
        else blocker = '提交确认窗口无法唯一识别，请手动处理';
      } else if (content) blocker = content.slice(0, 160);
    }
    if (!blocker && /请重新登录|登录已过期|访问过于频繁/.test(text(document.body).slice(0, 2000))) blocker = '页面要求重新登录或稍后重试';
    return {blocker, confirm};
  }
  function snapshot() {
    // WeakMap entries disappear with DOM nodes; prune strong action references on every scan.
    for (const [key, el] of nodes) if (!el.isConnected) nodes.delete(key);
    const shown = frameVisible();
    const quiz = shown ? readQuiz() : null, tasks = readTasks();
    // An explicit quiz result is completion evidence even on result pages without job wrappers.
    if (quiz?.complete && !tasks.some(t=>t.visible)) tasks.push({id:'quiz-result',complete:true,visible:true,title:'章节测验'});
    return {path: location.origin + location.pathname, visible: shown,
      backgroundPlayback, focusGuard: root.MoocFocusGuard ? {enabled: root.MoocFocusGuard.enabled} : null,
      contentVersion: root.MoocContentVersion || null,
      children: query(document, 'iframe').map(el => ({url: el.src || 'about:blank', visible: visible(el)})),
      videos: shown ? readVideos() : [], quiz,
      endedSurvey:shown ? readEndedSurvey() : null,
      tasks, navigation: window === window.top ? readNavigation() : null,
      dialogs: shown ? readDialogs() : {blocker: null, confirm: null}};
  }
  function requireClickable(key) {
    const el = get(key);
    if (!visible(el) || el.matches('[disabled], [aria-disabled="true"]')) throw new Error('目标控件不可见或不可点击');
    return el;
  }
  function chooseOption(key) {
    const el=requireClickable(key);
    const input=el.matches('input')?el:el.querySelector('input[type="radio"], input[type="checkbox"]');
    if (input) { if (input.disabled) throw new Error('题目选项不可操作');input.click();return; }
    const controls=el.matches('.num_option')?[el]:query(el,'.num_option').filter(visible);
    if (controls.length>1) throw new Error('无法唯一识别选项控件，请手动处理');
    const control=controls[0] || el;
    if (control.matches('[disabled], [aria-disabled="true"]')) throw new Error('题目选项不可操作');
    clickControl(control);
  }
  function clickControl(el) {
    const anchor=el.closest('a[href]');
    if (!anchor || !/^javascript:/i.test(anchor.getAttribute('href').trim())) { el.click();return; }
    // Platform click handlers do the work; the empty script URL is just a placeholder.
    // Prevent only its default navigation, without stopping any platform listeners.
    const prevent=event=>event.preventDefault();
    anchor.addEventListener('click',prevent,{capture:true,once:true});
    try { el.click(); } finally { anchor.removeEventListener('click',prevent,true); }
  }
  async function playVideo(key, isCancelled = () => false) {
    const v = requireClickable(key);
    if (!(v instanceof HTMLVideoElement)) throw new Error('目标不是视频');
    if (isCancelled()) throw new Error('操作已暂停');
    if (v.ended) return {ok: true, ended: true};
    v.playbackRate = 1;
    v.defaultPlaybackRate = 1;
    if (!v.paused) return {ok: true};
    let request = pendingPlays.get(v);
    if (!request) {
      // A preload=none player may not have a source until its own start control runs.
      // Click only the play control belonging to this player, never a seek control.
      const player = v.closest('.video-js');
      const scope = player || (query(document, 'video').filter(visible).length === 1 ? document : null);
      const buttons = scope ? query(scope, '.vjs-big-play-button').filter(el => visible(el) && !el.matches('[disabled], [aria-disabled="true"]')) : [];
      if (buttons.length > 1) throw new Error('无法唯一识别视频播放按钮，请手动点击播放，再点击开始');
      if (buttons.length === 1) buttons[0].click();
      if (isCancelled()) { v.pause(); throw new Error('操作已暂停'); }
      v.playbackRate = 1; v.defaultPlaybackRate = 1;
      request = Promise.resolve().then(() => {
        if (isCancelled() || !v.isConnected) throw new Error('操作已暂停或播放器已更换');
        return v.play();
      }).then(() => {
        if (isCancelled() || !v.isConnected) {
          if (!pendingPlays.has(v) || pendingPlays.get(v) === request) v.pause();
          throw new Error('操作已暂停或播放器已更换');
        }
        return {ok: !v.paused, loading: v.paused};
      }, error => {
        if (isCancelled() || !v.isConnected) throw new Error('操作已暂停或播放器已更换');
        if (error?.name === 'NotAllowedError') throw new Error('浏览器阻止了自动播放，请手动点击视频播放，再点击开始');
        const hasSource = Boolean(v.currentSrc || v.getAttribute('src') || v.querySelector('source[src]'));
        if (error?.name === 'NotSupportedError' && !hasSource && !v.error) return {ok: false, loading: true};
        throw new Error(`视频无法启动：${v.error?.message || error?.message || '请检查网络或手动点击播放'}。处理后点击开始`);
      });
      pendingPlays.set(v, request);
      const clear = () => { if (pendingPlays.get(v) === request) pendingPlays.delete(v); };
      request.then(clear, clear);
    }
    // Loading can keep play() pending. Release the coordinator to rescan and to stop.
    let timeout, cancelCheck;
    try {
      return await Promise.race([request, new Promise((resolve, reject) => {
        timeout = setTimeout(() => resolve({ok: false, loading: true}), 4000);
        cancelCheck = setInterval(() => {
          if (isCancelled() || !v.isConnected) {
            if (pendingPlays.get(v) === request) { v.pause(); pendingPlays.delete(v); }
            reject(new Error('操作已暂停或播放器已更换'));
          }
        }, 100);
      })]);
    } finally { clearTimeout(timeout); clearInterval(cancelCheck); }
  }
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  function selectionMatches(question, wanted) {
    return question.options.every(o => o.selected === wanted.includes(o.id));
  }
  async function fillQuiz(plan, bank, isCancelled) {
    const quiz = readQuiz();
    if (!quiz || quiz.incomplete || quiz.signature !== plan.signature) throw new Error('题目发生变化或提取不完整，已暂停');
    const fresh = C.planQuiz(quiz.questions, bank);
    if (!fresh.ok || JSON.stringify(fresh.matches.map(m => m.ids)) !== JSON.stringify(plan.matches.map(m => m.ids))) throw new Error('答案计划已变化');
    for (const match of fresh.matches) {
      let q = readQuestions().find(x => x.id === match.id);
      if (!q || q.options.some(o => !o.enabled)) throw new Error('题目选项不可操作');
      const changes = q.type === '多选题' ? q.options.filter(o => o.selected !== match.ids.includes(o.id))
        : q.options.filter(o => match.ids.includes(o.id) && !o.selected);
      for (const option of changes) {
        if (isCancelled()) throw new Error('操作已暂停');
        chooseOption(option.id);
        await delay(180);
      }
      q = readQuestions().find(x => x.id === match.id);
      if (!q || !selectionMatches(q, match.ids)) throw new Error('无法确认选中状态，已停止自动提交');
    }
    if (isCancelled()) throw new Error('操作已暂停');
    return {ok: true, filled: true};
  }
  function submitQuiz(plan, bank) {
    const quiz = readQuiz();
    if (!quiz || quiz.complete || quiz.incomplete || quiz.signature !== plan.signature) throw new Error('提交前页面状态变化');
    const fresh = C.planQuiz(quiz.questions, bank);
    if (!fresh.ok || fresh.matches.some(m => !selectionMatches(quiz.questions.find(q => q.id === m.id), m.ids))) throw new Error('提交前答案核验失败');
    if (quiz.submitIds.length !== 1) throw new Error('无法唯一识别提交按钮，请手动提交');
    clickControl(requireClickable(quiz.submitIds[0]));
    return {ok: true, clicked: true};
  }
  async function fillMatched(plan, bank, isCancelled) {
    function currentMatches() {
      const quiz=readQuiz();
      if (!quiz || quiz.fontError || quiz.complete || quiz.incomplete || quiz.signature!==plan.signature) throw new Error('题目发生变化或提取不完整，已停止填写');
      const matches=C.planQuiz(quiz.questions,bank).matches.filter(m=>m.ok);
      if (JSON.stringify(matches.map(m=>[m.id,m.ids]))!==JSON.stringify(plan.matches.map(m=>[m.id,m.ids]))) throw new Error('匹配答案已变化，已停止填写');
      return {quiz,matches};
    }
    const initial=currentMatches();let filled=0,preserved=0;
    for (const match of initial.matches) {
      if (isCancelled()) throw new Error('操作已暂停');
      let q=currentMatches().quiz.questions.find(q=>q.id===match.id);
      if (!q || q.options.some(o=>!o.enabled)) throw new Error('匹配题目的选项不可操作，请手动处理');
      if (q.options.some(o=>o.selected)) { preserved++;continue; }
      for (const key of match.ids) {
        if (isCancelled()) throw new Error('操作已暂停');
        currentMatches();
        chooseOption(key);
        await delay(180);
      }
      if (isCancelled()) throw new Error('操作已暂停');
      q=currentMatches().quiz.questions.find(q=>q.id===match.id);
      if (!q || !selectionMatches(q,match.ids)) throw new Error('无法确认匹配答案已在学习通选中，请手动处理');
      filled++;
    }
    return {ok:true,filled,preserved,matched:initial.matches.length};
  }
  function clickNavigation(key) { clickControl(requireClickable(key)); return {ok: true}; }
  function pauseVideos() { query(document, 'video').forEach(v => {
    if (!v.paused || pendingPlays.has(v)) v.pause();
    pendingPlays.delete(v);
  }); }
  function setBackgroundPlayback(value) { backgroundPlayback = value !== false; }
  root.MoocAdapter = {defaults, configure, setBackgroundPlayback, snapshot, readQuiz, playVideo, pauseVideos, fillQuiz, submitQuiz, fillMatched, clickNavigation};
})(globalThis);

'use strict';
function allowed(url) { try { const u = new URL(url); return u.protocol === 'https:' && (u.hostname === 'chaoxing.com' || u.hostname.endsWith('.chaoxing.com')); } catch { return false; } }
function studyPage(url) { try { return allowed(url) && /\/mycourse\/studentstudy\/?$/.test(new URL(url).pathname); } catch { return false; } }
function notificationId(tabId) { return `mooc-mismatch:${tabId}`; }
// Callbacks also work on the extension's minimum Chrome version (106).
function notificationCall(method, ...args) {
  return new Promise((resolve,reject)=>chrome.notifications[method](...args,result=>{
    const error=chrome.runtime.lastError;
    if (error) reject(new Error(error.message)); else resolve(result);
  }));
}
async function frames(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (!allowed(tab.url)) throw new Error('请在学习通 HTTPS 课程页面使用扩展');
  return (await chrome.webNavigation.getAllFrames({tabId})) || [];
}
async function broadcast(tabId, command, payload) {
  const list = await frames(tabId);
  return Promise.all(list.map(async f => {
    try {
      if (!f.documentId) throw new Error('无法确定 iframe 文档');
      const value = await chrome.tabs.sendMessage(tabId, {mooc: true, command, payload}, {documentId: f.documentId});
      return {frameId: f.frameId, documentId: f.documentId, parentFrameId: f.parentFrameId, url: f.url, value};
    } catch { return {frameId: f.frameId, parentFrameId: f.parentFrameId, url: f.url, unavailable: true}; }
  }));
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!message?.mooc) return;
  (async () => {
    if (message.command === 'NOTIFY_MISMATCH' || message.command === 'CLEAR_MISMATCH') {
      if (sender.id !== chrome.runtime.id || !sender.tab || sender.frameId !== 0) throw new Error('仅课程主页可以发送答题提醒');
      const tab=await chrome.tabs.get(sender.tab.id);
      if (!studyPage(tab.url)) throw new Error('仅学生学习页面可以发送答题提醒');
      const key=notificationId(tab.id);
      if (message.command === 'CLEAR_MISMATCH') return {cleared:await notificationCall('clear',key)};
      const {count,chapter}=message.payload || {};
      if (!Number.isInteger(count) || count<1 || count>1000) throw new Error('未匹配题目数量无效');
      if (await notificationCall('getPermissionLevel')!=='granted') return {notified:false};
      await notificationCall('create',key,{type:'basic',iconUrl:chrome.runtime.getURL('icons/course-128.png'),
        title:'创新创业课程助手',contextMessage:typeof chapter==='string'?chapter.slice(0,80):'当前章节测验',
        message:`有 ${count} 道题未匹配，请回到学习通人工补答并提交。已匹配题的选择会保留。`,
        silent:true,requireInteraction:false});
      return {notified:true};
    }
    if (['FRAME_SCAN', 'FRAME_CANCEL', 'FRAME_ENABLE'].includes(message.command)) {
      if (!sender.tab || sender.frameId !== 0) throw new Error('仅课程主页可以调度任务');
      return broadcast(sender.tab.id, {FRAME_SCAN:'SCAN', FRAME_CANCEL:'CANCEL', FRAME_ENABLE:'ENABLE'}[message.command], message.payload);
    }
    if (message.command === 'FRAME_ACTION') {
      if (!sender.tab || sender.frameId !== 0) throw new Error('仅课程主页可以执行任务');
      const list = await frames(sender.tab.id);
      if (!list.some(f => f.documentId === message.documentId)) throw new Error('页面已变化，请重新检查');
      return chrome.tabs.sendMessage(sender.tab.id, {mooc: true, command: 'ACTION', payload: message.payload}, {documentId: message.documentId});
    }
    if (message.command === 'POPUP_CONTROL') {
      if (sender.tab || sender.url !== chrome.runtime.getURL('popup.html')) throw new Error('无效的控制来源');
      await frames(message.tabId);
      return chrome.tabs.sendMessage(message.tabId, {mooc: true, command: 'CONTROL', payload: message.payload}, {frameId: 0});
    }
    throw new Error('未知命令');
  })().then(value => reply({ok: true, value}), error => reply({ok: false, error: error.message}));
  return true;
});
chrome.notifications.onClicked.addListener(async key=>{
  const match=/^mooc-mismatch:(\d+)$/.exec(key);
  if (!match) return;
  try {
    await notificationCall('clear',key);
    const tab=await chrome.tabs.get(Number(match[1]));
    if (!studyPage(tab.url)) return;
    await chrome.tabs.update(tab.id,{active:true});
    await chrome.windows.update(tab.windowId,{focused:true});
  } catch { /* The user may already have closed the course tab. */ }
});

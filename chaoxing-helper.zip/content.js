(function () {
  'use strict';
  if (globalThis.__moocHelperLoaded) return;
  globalThis.__moocHelperLoaded = true;
  const CONTENT_VERSION = '0.1.13';
  globalThis.MoocContentVersion = CONTENT_VERSION;
  const C = MoocCore, A = MoocAdapter;
  const isTop = window === window.top;
  const studyPage = isTop && /\/mycourse\/studentstudy\/?$/.test(location.pathname);
  let bank = null, settings = {autoSubmit: true, backgroundPlayback: true, selectors: {}}, cancelEpoch = 0, enabledRun = null;
  let initialized;
  async function rpc(command, extra = {}) {
    const result = await chrome.runtime.sendMessage({mooc: true, command, ...extra});
    if (!result?.ok) throw new Error(result?.error || '扩展连接中断，请刷新页面');
    return result.value;
  }
  const ready = chrome.storage.local.get(['answerBank', 'settings']).then(data => {
    bank = C.resolveBank(data.answerBank, MoocBuiltinBank);
    settings = {...settings, ...data.settings};
    A.configure(settings.selectors);
    A.setBackgroundPlayback(settings.backgroundPlayback);
    globalThis.MoocFocusGuard?.configure(settings);
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (!message?.mooc || sender.id !== chrome.runtime.id) return;
    (async () => {
      await ready;
      if (message.command === 'SCAN') return A.snapshot();
      if (message.command === 'ENABLE') {
        if (enabledRun !== message.payload.runId) cancelEpoch++;
        enabledRun = message.payload.runId; return {ok: true};
      }
      if (message.command === 'CANCEL') {
        if (!message.payload?.runId || message.payload.runId === enabledRun) {
          cancelEpoch++; enabledRun = null;
          if (message.payload?.pauseVideos) A.pauseVideos();
        }
        return {ok: true};
      }
      if (message.command === 'ACTION') {
        const epoch = cancelEpoch, p = message.payload;
        if (!p.runId || p.runId !== enabledRun) throw new Error('运行已暂停或已被新的运行替代');
        if (!A.snapshot().visible) throw new Error('任务页面当前不可见');
        if (p.kind === 'play') return A.playVideo(p.id, () => epoch !== cancelEpoch || enabledRun !== p.runId);
        if (p.kind === 'fill') return A.fillQuiz(p.plan, bank, () => epoch !== cancelEpoch || enabledRun !== p.runId);
        if (p.kind === 'submit') return A.submitQuiz(p.plan, bank);
        if (p.kind === 'fillMatched') return A.fillMatched(p.plan, bank, () => epoch !== cancelEpoch || enabledRun !== p.runId);
        if (p.kind === 'navigate' || p.kind === 'confirm') return A.clickNavigation(p.id);
        throw new Error('未知任务操作');
      }
      if (message.command === 'CONTROL' && isTop) {
        if (!studyPage) throw new Error('请先打开课程的“学生学习页面”，然后刷新');
        await initialized;
        return control(message.payload?.action);
      }
      throw new Error('当前页面不支持此命令');
    })().then(value => reply(message.command === 'CONTROL' ? value : {ok: true, value}), error => reply({ok: false, error: error.message}));
    return true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.answerBank) bank = C.resolveBank(changes.answerBank.newValue, MoocBuiltinBank);
    if (changes.settings) {
      settings = {autoSubmit: true, backgroundPlayback: true, selectors: {}, ...changes.settings.newValue};
      A.setBackgroundPlayback(settings.backgroundPlayback);
      globalThis.MoocFocusGuard?.configure(settings);
      try { A.configure(settings.selectors); } catch (error) { if (studyPage) pause(error.message); }
    }
    if (studyPage && (changes.answerBank || changes.settings)) {
      render();
      void pause('答案库或设置已更新，请点击开始重新检查');
    }
  });
  if (!studyPage) return;

  const params = new URL(location.href).searchParams;
  const course = params.get('courseId') || params.get('courseid');
  const scope = course ? C.hash(`${location.origin}:${course}:${params.get('clazzid') || params.get('classId') || ''}`) : null;
  const storageKey = `session:${scope}`;
  let state = {status: 'idle', phase: 'idle', message: '已内置《创新创业》答案，点击开始即可。其他课程可导入自己的答案库。',
    title: '', attempts: {}, completedTabs: {}, log: []};
  let generation = 0, busy = false, saveQueue = Promise.resolve(), panel, manualTask = null;
  const started = new Set(), progress = new Map(), videoStartup = new Map();
  let waitSince = 0, navigationSince = 0, oldContext = '';
  function sanitizeSnapshot(snapshot) {
    if (!snapshot) return snapshot;
    return {...snapshot, children:(snapshot.children || []).map(child => {
      let path = 'unknown'; try { const url = new URL(child.url); path = ['https:', 'http:'].includes(url.protocol) ? url.origin + url.pathname : url.protocol; } catch {}
      return {path, visible:child.visible};
    })};
  }
  window.addEventListener('blur', () => {
    // Focusing an embedded player can blur the parent window while the tab still has focus.
    setTimeout(() => {
      if (!settings.backgroundPlayback && state.status === 'running' && (document.visibilityState !== 'visible' || !document.hasFocus())) {
        void pause('课程页面已失去焦点。回到课程后点击开始。');
      }
    }, 0);
  });
  function context(nav) { return nav?.chapterKey || new URL(location.href).searchParams.get('chapterId') || C.hash(nav?.chapterTitle || 'unknown'); }
  function persist() {
    const copy = JSON.parse(JSON.stringify(state));
    saveQueue = saveQueue.catch(() => {}).then(() => chrome.storage.local.set({[storageKey]: copy}));
    return saveQueue;
  }
  async function update(patch) {
    if (Object.keys(patch).every(key => state[key] === patch[key])) return;
    state = {...state, ...patch};
    state.log = [...state.log, {time: new Date().toISOString(), status: state.status, phase: state.phase, message: state.message}].slice(-50);
    render();
    await persist();
  }
  async function pause(message = '已暂停，可手动处理页面后继续。') {
    generation++;
    cancelEpoch++;
    const cancelled = rpc('FRAME_CANCEL', {payload:{runId:state.runId, pauseVideos:true}}).catch(() => {});
    await update({status: 'paused', phase: 'paused', message});
    await cancelled;
  }
  async function control(action) {
    if (action === 'info') return {ok: true, contentVersion: CONTENT_VERSION, backgroundPlayback: settings.backgroundPlayback, state, bank: bank?.stats || null};
    if (action === 'diagnose') {
      const scan = await rpc('FRAME_SCAN');
      return {ok: true, diagnostics: {version: chrome.runtime.getManifest().version, contentVersion: CONTENT_VERSION,
        page: location.origin + location.pathname, state, bank: bank ? {name: bank.name, stats: bank.stats} : null,
        frames: scan.map(f => ({frameId: f.frameId, parentFrameId: f.parentFrameId, unavailable: f.unavailable,
          snapshot: sanitizeSnapshot(f.value?.value)}))}};
    }
    if (action === 'pause') { await pause(); return {ok: true}; }
    if (action === 'checkManual') {
      if (!manualTask) throw new Error('当前没有待人工处理的测验，请点击开始');
      await checkManual(); return {ok:true};
    }
    if (action === 'stop') {
      generation++; cancelEpoch++;
      manualTask = null;
      void rpc('CLEAR_MISMATCH').catch(()=>{});
      await rpc('FRAME_CANCEL', {payload:{runId:state.runId, pauseVideos:true}}).catch(() => {});
      await update({status: 'idle', phase: 'idle', manual:null, message: '已停止。再次开始会重新读取当前页面。'});
      return {ok: true};
    }
    if (action === 'resetAttempts') {
      if (state.status === 'running') throw new Error('请先停止，再重置提交记录');
      state.attempts = {};
      await update({message: '提交记录已重置。确认页面未提交后再开始。'});
      return {ok: true};
    }
    if (action === 'start' || action === 'resume') {
      if (manualTask) { await checkManual(); return {ok:true}; }
      if (!scope) throw new Error('无法识别课程编号，请打开具体课程章节');
      generation++; started.clear(); progress.clear(); videoStartup.clear(); waitSince = 0; navigationSince = 0;
      state.runId = crypto.randomUUID();
      const token = generation;
      await rpc('FRAME_ENABLE', {payload:{runId:state.runId}});
      if (generation !== token) return {ok:true};
      await update({status: 'running', phase: 'checking', manual:null, message: '正在读取页面和任务状态…'});
      void tick();
      return {ok: true};
    }
    throw new Error('未知控制操作');
  }
  async function beginManual(frame, quiz, reason, {fill=true}={}) {
    const token=generation, matches=fill ? C.planQuiz(quiz.questions,bank).matches.filter(m=>m.ok) : [];
    let result={filled:0,preserved:0,matched:0};
    if (matches.length) {
      await update({phase:'answering',message:`已可靠匹配 ${matches.length} 道题，正在学习通页面选中答案…`});
      if (!live(token)) return;
      result=await action(frame,{kind:'fillMatched',plan:{signature:quiz.signature,matches}});
      if (!live(token)) return;
    }
    const nav=A.snapshot().navigation;
    const task=manualTask={frame,chapter:context(nav),tab:nav?.tabs.find(t=>t.active)?.title || null};
    state.manual={stage:'waiting_page',total:quiz.questions.length,matched:matches.length,reason};
    const remaining=quiz.questions.length-matches.length;
    const summary=result.filled || result.preserved ? `已自动选中 ${result.filled} 道题${result.preserved?`，保留 ${result.preserved} 道题的已有选择`:''}。\n` : '';
    const explanation=fill && remaining ? `有 ${remaining} 道题未匹配，请在学习通人工补答。` : reason;
    await pause(`${summary}${explanation}\n请在学习通核对并提交，完成后点击“我已提交，检查并继续”。`);
    if (fill && remaining>0 && manualTask===task && generation===token+1 && state.status==='paused') {
      try {
        const notification=await rpc('NOTIFY_MISMATCH',{payload:{count:remaining,chapter:state.title}});
        if (!notification?.notified) throw new Error('未获准显示通知');
      } catch {
        if (manualTask===task && generation===token+1) await update({message:state.message+'\n桌面通知未显示，请允许 Chrome／扩展通知；可在此查看待人工处理状态。'});
      }
    }
  }
  async function readManualPage() {
    if (!manualTask) throw new Error('人工答题已结束，请重新开始');
    const task=manualTask;
    const response = await rpc('FRAME_SCAN');
    if (manualTask!==task) throw new Error('人工答题已取消');
    const visibility = C.frameVisibility(response.map(f=>({frameId:f.frameId,parentFrameId:f.parentFrameId,url:f.url,visible:f.value?.value?.visible,children:f.value?.value?.children})));
    const frame = response.find(f=>f.documentId===task.frame.documentId && f.value?.ok) || response.find(f=>f.frameId===task.frame.frameId && f.value?.ok);
    const nav = response.find(f=>f.frameId===0)?.value?.value?.navigation;
    if (!frame || visibility[frame.frameId] !== true || context(nav) !== task.chapter) throw new Error('课程页已变化，请停止后重新开始');
    if (response.filter(f=>visibility[f.frameId]===true && f.value?.value?.quiz).length>1) throw new Error('检测到多个测验页面，请只保留当前测验');
    if (task.tab && nav?.tabs.find(t=>t.active)?.title!==task.tab) throw new Error('当前任务已切换，请回到原测验检查提交状态');
    const snapshot = frame.value.value;
    const complete = nav?.chapterComplete === true || snapshot.quiz?.complete === true || (snapshot.tasks.some(t=>t.visible) && snapshot.tasks.filter(t=>t.visible).every(t=>t.complete===true));
    return {frame,snapshot,complete};
  }
  async function finishManual() {
    manualTask = null;
    void rpc('CLEAR_MISMATCH').catch(()=>{});
    await update({manual:null});
    return control('resume');
  }
  async function checkManual() {
    const task=manualTask,epoch=generation;
    const page = await readManualPage();
    if (manualTask!==task || generation!==epoch) return;
    if (page.complete) return finishManual();
    await update({message:page.snapshot.dialogs?.confirm ? '学习通正在等待提交确认，请在课程页面点击确认，再检查提交状态。' : '尚未确认提交完成。请在学习通补答并核对全部题目，点击页面底部“提交”；完成平台确认后，再点击“我已提交，检查并继续”。你的手动选择会保留。'});
  }
  function createPanel() {
    const host = document.createElement('div');
    host.id = 'mooc-helper-root';
    const shadow = host.attachShadow({mode: 'closed'});
    const style = document.createElement('style');
    style.textContent = `:host{all:initial;position:fixed;right:18px;bottom:18px;z-index:2147483646;font-family:system-ui,"Microsoft YaHei",sans-serif;color:#17223b;font-size:13px;width:340px;max-width:calc(100vw - 32px)}*{box-sizing:border-box}.card{background:#fff;border:1px solid #cbd5e1;border-radius:14px;box-shadow:0 8px 35px #15213b30;overflow:hidden}header{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#eff6ff;font-weight:700}main{padding:12px 14px;max-height:55vh;overflow:auto}.badge{font-size:11px;font-weight:400;color:#345}.title{font-weight:600;margin-bottom:8px}.message{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.65;padding:10px;background:#f1f5f9;border-radius:8px}.paused{background:#fff1f2;color:#9f1239}.meta{font-size:12px;color:#64748b;margin:8px 0}.buttons{display:flex;gap:6px;flex-wrap:wrap}button{font:inherit;cursor:pointer;padding:7px 10px;border:1px solid #cbd5e1;background:white;border-radius:7px;color:#1e293b}button.primary{background:#2563eb;color:white;border-color:#2563eb}button:disabled{opacity:.45;cursor:default}.mini{border:0;background:transparent;padding:2px 6px}details{margin-top:10px;color:#64748b}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px;line-height:1.5}[hidden]{display:none!important}`;
    style.textContent += '.options{margin-top:10px}.check{display:flex;gap:7px;align-items:flex-start;margin-top:9px;line-height:1.6;cursor:pointer}.check input{flex-shrink:0;margin:4px 0 0;accent-color:#2563eb}';
    shadow.append(style);
    const card = document.createElement('section'); card.className = 'card';
    const header = document.createElement('header'); header.append(document.createTextNode('创新创业课程助手'));
    const badge = document.createElement('span'); badge.className = 'badge'; badge.textContent = '无倍速 无拖拽';
    const collapse = document.createElement('button'); collapse.className = 'mini'; collapse.textContent = '收起';
    header.append(badge, collapse);
    const main = document.createElement('main');
    const title = document.createElement('div'); title.className = 'title';
    const message = document.createElement('div'); message.className = 'message'; message.setAttribute('role', 'status'); message.setAttribute('aria-live', 'polite');
    const meta = document.createElement('div'); meta.className = 'meta';
    const buttons = document.createElement('div'); buttons.className = 'buttons';
    const controls = {};
    for (const [action, label] of [['start','开始'],['stop','停止']]) {
      const b = document.createElement('button'); b.textContent = label;
      b.dataset.action = action;
      if (action === 'start') b.className = 'primary';
      b.addEventListener('click', () => control(action).catch(error => pause(error.message)));
      controls[action] = b; buttons.append(b);
    }
    const manualCheck = document.createElement('button'); manualCheck.className = 'manual-check primary';
    manualCheck.textContent = '我已提交，检查并继续'; manualCheck.hidden = true;
    manualCheck.addEventListener('click', async () => {
      manualCheck.disabled = true;
      try { await control('checkManual'); } catch (error) { await pause(error.message); }
      finally { render(); }
    });
    const options = document.createElement('div'); options.className = 'options';
    const settingInputs = {};
    for (const [key, label] of [['autoSubmit', '题目匹配成功后自动提交'], ['backgroundPlayback', '移开鼠标、切换窗口或最小化后继续运行']]) {
      const row = document.createElement('label'); row.className = 'check';
      const input = document.createElement('input'); input.type = 'checkbox'; input.name = key;
      input.addEventListener('change', async () => {
        const value = input.checked; input.disabled = true;
        try {
          const data = await chrome.storage.local.get('settings');
          await chrome.storage.local.set({settings: {...settings, ...data.settings, [key]: value}});
        } catch (error) { await pause(`设置保存失败：${error.message}`); }
        finally { input.disabled = false; render(); }
      });
      row.append(input, document.createTextNode(label)); options.append(row); settingInputs[key] = input;
    }
    const details = document.createElement('details');
    const summary = document.createElement('summary'); summary.textContent = '最近状态';
    const logs = document.createElement('pre'); details.append(summary, logs);
    const hint=document.createElement('p');hint.className='hint';hint.textContent='如果题目匹配失败，由人工回答';
    main.append(title, message, meta, buttons, manualCheck, options, hint, details); card.append(header, main); shadow.append(card);
    style.textContent += '.manual-check{margin-top:9px}.hint{font-size:12px;color:#64748b;margin:9px 0 0}.complete{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}button:focus-visible{outline:3px solid #93c5fd;outline-offset:2px}';
    collapse.addEventListener('click', () => { main.hidden = !main.hidden; collapse.textContent = main.hidden ? '展开' : '收起'; });
    (document.body || document.documentElement).append(host);
    panel = {main, title, message, meta, controls, settingInputs, logs, collapse, manualCheck};
    render();
  }
  function render() {
    if (!panel) return;
    panel.title.textContent = state.title || '当前课程章节';
    panel.message.textContent = state.message;
    panel.message.className = 'message' + (state.status === 'paused' ? ' paused' : state.status==='done'?' complete':'');
    panel.meta.textContent = `${bank ? `当前题库：${bank.stats.total} 道题` : '尚未导入答案库'} · ${settings.backgroundPlayback ? '允许后台运行' : '仅前台运行'} · ${settings.autoSubmit ? '匹配完整后自动提交' : '选好后由你提交'}`;
    panel.controls.start.disabled = state.status === 'running' || Boolean(manualTask);
    panel.manualCheck.hidden = !manualTask;
    panel.manualCheck.disabled = state.status !== 'paused';
    panel.controls.stop.disabled = state.status === 'idle';
    panel.settingInputs.autoSubmit.checked = settings.autoSubmit;
    panel.settingInputs.backgroundPlayback.checked = settings.backgroundPlayback !== false;
    panel.logs.textContent = state.log.slice(-8).map(l => `${new Date(l.time).toLocaleTimeString()} ${l.message}`).join('\n');
    if (state.status === 'paused') { panel.main.hidden = false; panel.collapse.textContent = '收起'; }
  }
  async function action(frame, payload) {
    const reply = await rpc('FRAME_ACTION', {documentId: frame.documentId, payload:{...payload,runId:state.runId}});
    if (!reply?.ok) throw new Error(reply?.error || '任务操作失败');
    return reply.value;
  }
  function live(token) { return generation === token && state.status === 'running'; }
  async function tick() {
    if (busy || state.status !== 'running') return;
    busy = true;
    const token = generation;
    let manualContext=null;
    try {
      if (!settings.backgroundPlayback && (document.visibilityState !== 'visible' || !document.hasFocus())) {
        await update({phase: 'waiting_focus', message: '请保持课程页面在前台；恢复前台后继续检查。'}); return;
      }
      const actual = new URL(location.href).searchParams;
      const actualCourse = actual.get('courseId') || actual.get('courseid');
      const actualScope = actualCourse ? C.hash(`${location.origin}:${actualCourse}:${actual.get('clazzid') || actual.get('classId') || ''}`) : null;
      if (actualScope !== scope || !/\/mycourse\/studentstudy\/?$/.test(location.pathname)) throw new Error('课程页面已变化，请刷新后重新开始');
      await rpc('FRAME_ENABLE', {payload:{runId:state.runId}});
      if (!live(token)) return;
      const response = await rpc('FRAME_SCAN');
      if (!live(token)) return;
      const frames = response.filter(f => f.value?.ok && f.value.value);
      const visibility = C.frameVisibility(response.map(f => ({frameId:f.frameId, parentFrameId:f.parentFrameId,
        url:f.url, visible:f.value?.value?.visible, children:f.value?.value?.children})));
      for (const frame of frames) {
        const snapshot = frame.value.value;
        if (visibility[frame.frameId] === null && (snapshot.quiz || snapshot.videos.length)) {
          throw new Error('无法确认某个 iframe 任务是否可见，请只打开当前任务或导出页面诊断');
        }
        if (visibility[frame.frameId] !== true) {
          snapshot.visible = false; snapshot.quiz = null; snapshot.videos = []; snapshot.dialogs = {blocker:null,confirm:null};
        }
      }
      const top = frames.find(f => f.frameId === 0);
      if (!top) throw new Error('无法读取课程主页，请刷新页面');
      const nav = top.value.value.navigation;
      if (!nav?.currentFound) throw new Error('无法识别目录中当前章节，请导出页面诊断或检查高级选择器设置');
      const chapterContext = context(nav);
      if (state.title !== nav?.chapterTitle && nav?.chapterTitle) await update({title: nav.chapterTitle});
      if (!live(token)) return;
      if (navigationSince) {
        if (oldContext === chapterContext) {
          if (Date.now() - navigationSince > 15000) throw new Error('切换后未确认章节变化，请手动打开下一章节');
          return;
        }
        navigationSince = 0; started.clear(); progress.clear(); videoStartup.clear(); waitSince = 0;
        await update({phase:'checking', message:'章节已切换，等待新任务加载…'}); return;
      }
      const blocker = frames.find(f => f.value.value.dialogs?.blocker);
      if (blocker) throw new Error(`需要你处理页面：${blocker.value.value.dialogs.blocker}`);
      const endedSurvey=frames.some(f=>f.value.value.visible && f.value.value.endedSurvey?.ended);
      if (nav.allTaskPointsComplete || (nav.lastChapter && endedSurvey && !nav.catalogFiltered && nav.catalogPending===0)) {
        await update({status:'done',phase:'done',manual:null,message:'恭喜完成课程全部任务点'});return;
      }
      const pendingEntries = Object.entries(state.attempts).filter(([,a]) => a.chapter === chapterContext);
      const confirmationFrames = frames.filter(f => f.value.value.dialogs?.confirm);
      if (confirmationFrames.length>1) throw new Error('检测到多个提交确认窗口，请手动处理');
      const confirm = confirmationFrames[0];
      if (confirm) {
        const currentQuizzes=frames.filter(f=>f.value.value.quiz && !f.value.value.quiz.complete);
        if (currentQuizzes.length>1) throw new Error('检测到多个测验页面，请手动确认当前任务');
        const signature=currentQuizzes[0]?.value.value.quiz.signature;
        const key=signature ? `${chapterContext}:${signature}` : null;
        const pending=key ? [[key,state.attempts[key]]].filter(([,a])=>a?.stage==='sent')
          : pendingEntries.filter(([,a])=>a.stage==='sent' && !a.confirmed);
        if (pending.length !== 1) throw new Error('页面出现提交确认窗口，请手动处理');
        if (!settings.autoSubmit) throw new Error('自动提交已关闭，请在学习通完成提交确认');
        if (pending[0][1].confirmed) {
          if (Date.now()-pending[0][1].time>60000) throw new Error('已确认提交，但窗口仍未关闭，请查看平台结果；扩展不会重复点击。');
          await update({phase:'waiting_submit',message:'已确认提交，等待学习通关闭窗口并显示完成。'});return;
        }
        pending[0][1].confirmed = true;
        await persist(); if (!live(token)) return;
        await action(confirm, {kind: 'confirm', id: confirm.value.value.dialogs.confirm.id});
        await update({phase: 'waiting_submit', message: '已确认提交，等待页面更新完成状态…'}); return;
      }
      const tasks = frames.flatMap(f => f.value.value.tasks);
      const allKnownTasksDone = tasks.length > 0 && tasks.every(t => t.complete === true);
      const pageDone = nav?.chapterComplete === true || allKnownTasksDone;
      const quizzes = pageDone ? [] : frames.filter(f => f.value.value.visible && f.value.value.quiz && !f.value.value.quiz.complete);
      const videos = pageDone ? [] : frames.flatMap(f => f.value.value.videos.map(v => ({frame: f, video: v}))).filter(x => x.video.complete !== true);
      // More than one active quiz/player is ambiguous; never run simultaneous course videos.
      if (quizzes.length > 1) throw new Error('检测到多个测验页面，无法确认当前任务，请只保留当前任务');
      if (quizzes.length && videos.some(x => !x.video.ended)) throw new Error('同时检测到视频和未完成测验，请手动打开要处理的任务');
      if (quizzes.length) {
        const frame = quizzes[0], quiz = frame.value.value.quiz;
        manualContext={frame,quiz};
        if (quiz.fontError) throw new Error(quiz.fontError);
        if (quiz.incomplete) throw new Error('提取的题目数量与页面不一致，请手动处理或检查页面选择器');
        const key = `${chapterContext}:${quiz.signature}`;
        const attempt = state.attempts[key];
        if (attempt?.stage === 'sent') {
          if (Date.now() - attempt.time > 60000) throw new Error('已尝试提交，但未确认完成。请查看页面结果或手动处理；扩展不会重复点击提交。');
          await update({phase: 'waiting_submit', message: '已提交，等待学习通显示任务完成；如有确认或验证窗口，请在课程页处理。'}); return;
        }
        if (!bank) throw new Error('当前任务是测验，请先从扩展弹窗导入 MD 答案库');
        const plan = C.planQuiz(quiz.questions, bank);
        if (!plan.ok) {
          const missing = plan.matches.filter(m => !m.ok);
          await beginManual(frame,quiz,`有 ${missing.length} 道题需要人工核对：\n${missing.map(m => `• ${m.stem}\n  ${m.reason}`).join('\n')}`);return;
        }
        const selectionsMatch = plan.matches.every(m => quiz.questions.find(q => q.id === m.id).options.every(o => o.selected === m.ids.includes(o.id)));
        if (!selectionsMatch) {
          await update({phase: 'answering', message: `已匹配全部 ${quiz.questions.length} 道题，正在按选项内容填写…`});
          if (!live(token)) return;
          await action(frame, {kind: 'fill', plan});
          return; // A separate fresh scan verifies all selections before submission.
        }
        if (!settings.autoSubmit) { await beginManual(frame,quiz,'全部答案已在学习通选中，自动提交已关闭。请在学习通核对并提交。');return; }
        if (quiz.submitIds.length !== 1) throw new Error('无法唯一识别提交按钮，请手动提交，然后点击开始');
        state.attempts[key] = {chapter: chapterContext, stage: 'sent', time: Date.now(), confirmed: false};
        await persist(); if (!live(token)) return;
        await action(frame, {kind: 'submit', plan});
        await update({phase: 'waiting_submit', message: '已点击提交，等待页面确认完成。'}); return;
      }
      const unfinishedVideos = videos.filter(x => !x.video.ended);
      if (unfinishedVideos.length > 1) throw new Error('检测到多个未完成视频，请手动打开当前视频任务');
      if (unfinishedVideos.length === 1) {
        waitSince = 0;
        const {frame, video: v} = unfinishedVideos[0], key = `${frame.documentId}:${v.id}`;
        if (v.error) throw new Error(`视频加载失败：${v.error}`);
        if (!started.has(key) || v.rate !== 1) {
          const record = videoStartup.get(key) || {time: Date.now(), attempts: 0, lastTry: 0, readyState: v.readyState};
          videoStartup.set(key, record);
          if (v.paused && Date.now() - record.time > 45000) throw new Error('新视频未能在 45 秒内启动，请手动点击中央播放按钮，再点击开始；可导出诊断检查播放器状态');
          if (v.readyState > record.readyState) { record.attempts = 0; record.readyState = v.readyState; }
          if (v.paused && (record.attempts >= 3 || Date.now() - record.lastTry < 5000)) {
            await update({phase: 'loading_video', message: '已请求启动新视频，正在等待播放器加载…'}); return;
          }
          record.attempts++; record.lastTry = Date.now();
          if (!live(token)) return;
          const result = await action(frame, {kind: 'play', id: v.id});
          if (!live(token)) return;
          if (result?.ok) {
            started.add(key); videoStartup.delete(key);
            await update({phase: 'playing', message: '视频按正常速度播放中，结束后核实任务完成状态。'});
          } else await update({phase: 'loading_video', message: '已请求启动新视频，正在等待播放器加载…'});
          return;
        }
        if (v.paused) { await update({phase: 'waiting_play', message: '视频已暂停。请手动点击播放；扩展将继续观察。'}); return; }
        const record = progress.get(key);
        if (!record || v.position > record.position + .2) progress.set(key, {position: v.position, time: Date.now()});
        const stalled = record && Date.now() - record.time > 45000;
        const total = v.duration ? ` / ${Math.floor(v.duration / 60)}:${String(Math.floor(v.duration % 60)).padStart(2,'0')}` : '';
        await update({phase: stalled ? 'buffering' : 'playing', message: stalled ? '视频暂未推进，正在等待缓冲；请检查页面或网络。'
          : `正常速度播放：${Math.floor(v.position / 60)}:${String(Math.floor(v.position % 60)).padStart(2,'0')}${total}`}); return;
      }
      const gate = C.canAdvance({chapterComplete: nav?.chapterComplete, tasks});
      if (!gate.ok) {
        const activeTab = nav?.tabs.find(t => t.active);
        const visibleTasks = tasks.filter(t => t.visible);
        if (activeTab && visibleTasks.length && visibleTasks.every(t => t.complete === true)) {
          state.completedTabs[`${chapterContext}:${activeTab.title}`] = true;
          const next = nav.tabs.find(t => !t.active && t.complete !== true && !state.completedTabs[`${chapterContext}:${t.title}`]);
          if (next) {
            await update({phase: 'switching_task', message: `当前任务已完成，打开 ${next.title}…`});
            if (!live(token)) return;
            await action(top, {kind: 'navigate', id: next.id}); waitSince = 0; return;
          }
        }
        if (!waitSince) waitSince = Date.now();
        if (Date.now() - waitSince > 60000) {
          const unavailable = response.filter(f => f.unavailable).length;
          throw new Error(`尚有任务未确认完成，请检查课程页面后点击开始。${unavailable ? `有 ${unavailable} 个任务页面尚未接入，可导出诊断。` : ''}`);
        }
        await update({phase: 'waiting_complete', message: videos.length ? '视频已自然结束，等待页面更新任务完成标记…' : '等待任务加载或页面确认完成…'}); return;
      }
      // When only task markers (rather than the chapter itself) indicate completion,
      // every separate task tab must also be accounted for.
      if (nav?.chapterComplete !== true && nav?.tabs.length > 1) {
        const active = nav.tabs.find(t => t.active);
        if (active) state.completedTabs[`${chapterContext}:${active.title}`] = true;
        const nextTask = nav.tabs.find(t => !t.active && t.complete !== true && !state.completedTabs[`${chapterContext}:${t.title}`]);
        if (nextTask) {
          await update({phase: 'switching_task', message: `打开下一任务：${nextTask.title}`});
          if (!live(token)) return;
          await action(top, {kind: 'navigate', id: nextTask.id}); return;
        }
        if (!active && nav.tabs.some(t => t.complete !== true && !state.completedTabs[`${chapterContext}:${t.title}`])) throw new Error('无法确认当前任务标签，请手动切换任务');
      }
      if (!nav?.currentFound) throw new Error('无法识别目录中当前章节，请检查高级选择器设置');
      if (nav.lastChapter) {
        if (nav.catalogPending>0 || nav.catalogFiltered) { await pause('目录中仍有任务未确认完成，请查看完整目录并处理后点击开始。');return; }
        await update({status: 'done', phase: 'done', message: '当前章节任务已完成。'}); return;
      }
      if (!nav.nextId) throw new Error('当前章节已完成，但无法找到下一章节，请手动切换');
      oldContext = chapterContext; navigationSince = Date.now();
      await update({phase: 'navigating', fromChapter: chapterContext, message: '任务已全部完成，正在打开下一章节…'});
      if (!live(token)) return;
      await action(top, {kind: 'navigate', id: nav.nextId});
    } catch (error) {
      if (live(token)) {
        if (manualContext) await beginManual(manualContext.frame,manualContext.quiz,error.message,{fill:false});
        else await pause(error.message);
      }
    }
    finally { busy = false; }
  }
  initialized = (async () => {
    await ready;
    const saved = (await chrome.storage.local.get(storageKey))[storageKey];
    if (saved) state = {...state, ...saved};
    if (state.manual) { state.manual=null;state.message='页面已刷新，请点击开始重新读取测验和课程页已有选择。'; }
    if (settings.backgroundPlayback && state.status === 'paused' && /失去焦点|恢复前台/.test(state.message)) {
      state.message = '后台运行已启用，点击开始重新启动当前任务。';
    }
    const oldRun = state.status === 'running';
    const loadedChapter = context(A.snapshot().navigation);
    const expectedNavigation = oldRun && state.phase === 'navigating'
      && state.fromChapter && state.fromChapter !== loadedChapter;
    if (oldRun && !expectedNavigation) { state.status = 'paused'; state.phase = 'paused'; state.message = '页面已刷新。点击开始重新读取任务状态；提交记录已保留。'; }
    createPanel(); await persist();
    if (expectedNavigation) {
      state.runId = crypto.randomUUID();
      await rpc('FRAME_ENABLE', {payload:{runId:state.runId}});
      state.phase = 'checking'; void tick();
    }
    setInterval(() => { void tick(); }, 2000);
  })().catch(error => {
    state.status = 'paused'; state.message = `初始化失败：${error.message}`;
    if (!panel) createPanel(); else render();
  });
})();

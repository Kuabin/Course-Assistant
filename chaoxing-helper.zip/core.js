/* Pure functions shared by the popup, content scripts and Node tests. */
(function (root) {
  'use strict';
  const TYPES = ['单选题', '多选题', '判断题'];
  function normalize(value) {
    return String(value ?? '').normalize('NFKC')
      .replace(/[，]/g, ',').replace(/[。]/g, '.').replace(/[：]/g, ':')
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'")
      .replace(/\s+/g, '').replace(/\(\)/g, '').replace(/[.?!！？]+$/g, '');
  }
  function hash(value) {
    let h = 2166136261;
    for (const char of String(value)) { h ^= char.charCodeAt(0); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16);
  }
  function truth(value) {
    const text = normalize(value);
    if (['对', '正确', '√', '是', 'true'].includes(text)) return true;
    if (['错', '错误', '×', '✕', '否', 'false'].includes(text)) return false;
    return null;
  }
  function extractAnswer(text, type) {
    const source = text.normalize('NFKC');
    const tokens = [...source.matchAll(/\(\s*(正确|错误|对|错|[A-H]{1,8})\s*\)/g)];
    if (tokens.length === 1) {
      const token = tokens[0];
      return {stem: source.slice(0, token.index) + '()' + source.slice(token.index + token[0].length),
        answer: token[1], format: '括号'};
    }
    if (tokens.length > 1) return {stem: source, answer: null, error: '存在多个答案标记'};
    const suffix = source.match(/(?:\(\s*)?(正确|错误|对|错|[A-H]{1,8})\s*[).。!！?？]*\s*$/);
    if (!suffix) return {stem: source, answer: null, error: '未识别到答案标记'};
    // Bare suffixes are permitted by the supplied bank, but always surfaced during import.
    return {stem: source.slice(0, suffix.index), answer: suffix[1], format: '行尾', warning: '行尾答案格式，请核对导入预览'};
  }
  function parseMarkdown(markdown, name = '答案.md') {
    const entries = [], issues = [];
    let chapter = '', current = null;
    function finish() {
      if (!current) return;
      const parsed = extractAnswer(current.raw, current.type);
      const issue = parsed.error;
      const answer = current.type === '判断题' ? truth(parsed.answer) : parsed.answer;
      const labels = typeof answer === 'string' ? [...answer] : [];
      const reasons = [];
      if (issue) reasons.push(issue);
      if (current.type === '判断题' && answer === null) reasons.push('判断题答案不是对/错');
      if (current.type !== '判断题') {
        if (!labels.length || labels.some(x => !/^[A-H]$/.test(x))) reasons.push('选择题答案无效');
        if (current.type === '单选题' && labels.length !== 1) reasons.push('单选题有多个答案');
        if (new Set(labels).size !== labels.length) reasons.push('答案字母重复');
        if (!current.options.length) reasons.push('选择题没有选项内容');
        if (labels.some(x => !current.options.some(o => o.label === x))) reasons.push('答案对应的选项缺失');
        if (new Set(current.options.map(o => o.label)).size !== current.options.length) reasons.push('选项字母重复');
        if (new Set(current.options.map(o => normalize(o.text))).size !== current.options.length) reasons.push('选项内容重复');
      }
      const entry = {...current, id: `${name}:${current.line}`, stem: parsed.stem.trim(), answer,
        key: normalize(parsed.stem), valid: reasons.length === 0,
        answerTexts: labels.map(x => current.options.find(o => o.label === x)?.text).filter(Boolean)};
      entries.push(entry);
      if (reasons.length) issues.push({line: current.line, chapter, severity: 'error', message: reasons.join('；')});
      if (parsed.warning) issues.push({line: current.line, chapter, severity: 'warning', message: parsed.warning});
      current = null;
    }
    markdown.split(/\r?\n/).forEach((line, index) => {
      const heading = line.match(/^##\s+(.+)/);
      if (heading) { finish(); chapter = heading[1].trim(); return; }
      if (/^\s*\*\*新增题(?:[（(][^\r\n]*[）)])?[:：]\*\*\s*$/.test(line)) { finish(); return; }
      const question = line.match(/^\s*(?:\*\*)?\d+[.、．]\s*【(单选题|多选题|判断题)】(?:\*\*)?\s*(.+)/);
      if (question) { finish(); current = {chapter, type: question[1], raw: question[2].trim(), options: [], line: index + 1}; return; }
      if (/^以上课程答案/.test(line.trim())) { finish(); return; }
      if (!current) return;
      const option = line.match(/^\s*[-*]\s*([A-H])[、.．:：]\s*(.+)/);
      if (option) current.options.push({label: option[1], text: option[2].trim()});
      else if (line.trim() && !/^[-#>]/.test(line.trim())) {
        issues.push({line: index + 1, chapter, severity: 'warning', message: '未识别的内容行，未自动拼入题干或选项'});
        current.unparsed = true;
      }
    });
    finish();
    for (const entry of entries) if (entry.unparsed) entry.valid = false;
    return {schema: 1, name, revision: hash(markdown), importedAt: new Date().toISOString(), entries, issues,
      stats: {total: entries.length, usable: entries.filter(e => e.valid).length,
        invalid: entries.filter(e => !e.valid).length, warnings: issues.filter(i => i.severity === 'warning').length}};
  }
  function matchQuestion(question, bank) {
    if (!TYPES.includes(question.type)) return {ok: false, reason: '不支持的题型'};
    if (question.hasImage) return {ok: false, reason: '题目包含图片，需要人工核对'};
    const candidates = (bank?.entries || []).filter(e => e.key === normalize(question.stem) && e.type === question.type);
    if (!candidates.length) return {ok: false, reason: '答案库中没有相同题干'};
    // A broken or conflicting duplicate must not be hidden by a valid entry.
    if (candidates.some(e => !e.valid)) return {ok: false, reason: '相同题干的答案库条目存在解析异常'};
    if (!question.options?.length || question.options.some(o => !normalize(o.text))) return {ok: false, reason: '页面选项不完整'};
    const pageTexts = question.options.map(o => normalize(o.text));
    if (new Set(pageTexts).size !== pageTexts.length) return {ok: false, reason: '页面有重复选项内容'};
    if (question.type === '判断题') {
      if (new Set(candidates.map(e => e.answer)).size !== 1) return {ok: false, reason: '答案库中的判断答案冲突'};
      if (question.options.length !== 2 || question.options.some(o => truth(o.text) === null)
          || new Set(question.options.map(o => truth(o.text))).size !== 2) return {ok: false, reason: '无法可靠识别对/错选项'};
      return {ok: true, ids: question.options.filter(o => truth(o.text) === candidates[0].answer).map(o => o.id), source: candidates[0].id};
    }
    const optionSet = JSON.stringify([...pageTexts].sort());
    // Explicitly supplied variants share a stem but must match the entire option set.
    const variants = candidates.filter(e => JSON.stringify(e.options.map(o => normalize(o.text)).sort()) === optionSet);
    if (!variants.length) {
      return {ok: false, reason: '题干相同，但答案库与页面的选项不一致'};
    }
    const answers = variants.map(e => JSON.stringify(e.answerTexts.map(normalize).sort()));
    if (new Set(answers).size !== 1) return {ok: false, reason: '答案库中的选择答案冲突'};
    const wanted = variants[0].answerTexts.map(normalize);
    return {ok: true, ids: question.options.filter(o => wanted.includes(normalize(o.text))).map(o => o.id), source: variants[0].id};
  }
  function planQuiz(questions, bank) {
    const matches = questions.map(q => ({id: q.id, stem: q.stem, ...matchQuestion(q, bank)}));
    return {ok: questions.length > 0 && matches.every(m => m.ok), matches,
      signature: hash(JSON.stringify(questions.map(q => [q.type, normalize(q.stem), q.options.map(o => normalize(o.text)).sort()])
        .sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b)))))};
  }
  function canAdvance(snapshot) {
    if (snapshot.chapterComplete === true) return {ok: true};
    if (snapshot.tasks?.length && snapshot.tasks.every(t => t.complete === true)) return {ok: true};
    return {ok: false, reason: '页面尚未明确显示当前章节的任务已全部完成'};
  }
  function frameVisibility(frames) {
    const byId = new Map(frames.map(f => [f.frameId, f])), result = {};
    function resolve(id, seen = new Set()) {
      if (Object.hasOwn(result, id)) return result[id];
      if (seen.has(id)) return null;
      const frame = byId.get(id); if (!frame) return null;
      if (frame.visible === false) return result[id] = false;
      if (id === 0) return result[id] = true;
      seen.add(id);
      const parentVisible = resolve(frame.parentFrameId, seen);
      if (parentVisible !== true) return result[id] = parentVisible;
      const parent = byId.get(frame.parentFrameId);
      const children = parent?.children || [];
      const exact = children.filter(c => c.url === frame.url);
      if (exact.length && new Set(exact.map(c => c.visible)).size === 1) return result[id] = exact[0].visible;
      const siblings = frames.filter(f => f.parentFrameId === frame.parentFrameId);
      if (!exact.length && children.length === 1 && siblings.length === 1) return result[id] = children[0].visible;
      return result[id] = null;
    }
    frames.forEach(f => resolve(f.frameId)); return result;
  }
  function resolveBank(saved, builtin) {
    if (!saved) return builtin;
    if (saved.name === builtin?.name && builtin.supersededRevisions?.includes(saved.revision)) return builtin;
    return saved;
  }
  const api = {normalize, hash, truth, parseMarkdown, matchQuestion, planQuiz, canAdvance, frameVisibility, resolveBank};
  root.MoocCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);

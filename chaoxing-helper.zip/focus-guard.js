(function () {
  'use strict';
  if (globalThis.MoocFocusGuard) return;
  const player = /\/ananas\/modules\/video\//.test(location.pathname);
  const course = window === window.top && /\/mycourse\/studentstudy\/?$/.test(location.pathname);
  if (!player && !course) return;
  // Register before the site's scripts. DOM event dispatch is shared with the page;
  // no MAIN-world injection, fake focus properties, or removal of editor listeners.
  let enabled = true;
  function hasPlayer() {
    return player || Boolean(document.querySelector('video, iframe#iframe'));
  }
  function preventLeavePause(event) {
    if (!enabled || !hasPlayer()) return;
    if (event.type === 'mouseout' && event.relatedTarget !== null) return;
    if (event.type === 'blur' && event.target !== window) return;
    if (event.type === 'visibilitychange' && event.target !== document) return;
    event.stopImmediatePropagation();
  }
  window.addEventListener('mouseout', preventLeavePause, true);
  window.addEventListener('blur', preventLeavePause, true);
  document.addEventListener('visibilitychange', preventLeavePause, true);
  function configure(settings) { enabled = settings?.backgroundPlayback !== false; }
  globalThis.MoocFocusGuard = {get enabled() { return enabled; }, configure};
  chrome.storage.local.get('settings').then(data => configure(data.settings)).catch(() => {});
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) configure(changes.settings.newValue);
  });
})();

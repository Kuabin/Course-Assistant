(function (root) {
  'use strict';
  const MAX_FONT_BYTES = 5 * 1024 * 1024;
  const cache = new Map();
  let faceSources = null;
  function begin() { faceSources = null; }
  function sources() {
    if (faceSources) return faceSources;
    const css = [...document.querySelectorAll('style')].map(el => el.textContent);
    function rules(list) {
      for (const rule of list) {
        if (rule.type === 5) css.push(rule.cssText);
        else if (rule.cssRules) rules(rule.cssRules);
      }
    }
    for (const sheet of document.styleSheets) { try { rules(sheet.cssRules); } catch { /* Inaccessible external styles cannot supply a local font. */ } }
    const values = new Set();
    for (const text of css) for (const face of text.matchAll(/@font-face\s*\{([^{}]*)\}/gi)) {
      if (!/font-family\s*:\s*["']?font-cxsecret["']?\s*(?:;|$)/i.test(face[1])) continue;
      for (const url of face[1].matchAll(/url\(\s*["']?(data:[^\s"')]+)["']?\s*\)/gi)) values.add(url[1]);
    }
    faceSources = [...values];
    return faceSources;
  }
  function fontData() {
    const found = sources();
    if (found.length !== 1) throw new Error(found.length ? '检测到多个混淆字体源，无法可靠区分，请手动处理当前测验' : '检测到混淆字体，但未找到页面内嵌字体，请刷新测验；仍失败时手动处理');
    const source = found[0];
    if (cache.has(source)) return cache.get(source);
    const tools = root.MoocFontTools;
    if (!tools || !root.MoocGlyphTable) throw new Error('本地字体还原组件未加载，请重新加载扩展并刷新整个课程页面');
    const payload = source.match(/^data:[^,]*;base64,([A-Za-z0-9+/=]+)$/i)?.[1];
    if (!payload || payload.length > MAX_FONT_BYTES * 4 / 3 + 4) throw new Error('混淆字体格式不支持或字体文件过大，请手动处理');
    let font;
    try {
      const bytes = Uint8Array.from(atob(payload), ch => ch.charCodeAt(0));
      const signature = String.fromCharCode(...bytes.slice(0,4));
      if (!['\x00\x01\x00\x00', 'OTTO'].includes(signature)) throw new Error('不支持的字体容器');
      font = tools.Typr.parse(bytes.buffer)[0];
      if (!font?.cmap || (!font.glyf && !font['CFF '])) throw new Error('字体缺少字形表');
    } catch { throw new Error('无法解析页面混淆字体，请刷新测验；仍失败时手动处理'); }
    const value = {font, chars: new Map(), fingerprint: tools.md5(payload)};
    cache.set(source, value);
    if (cache.size > 4) cache.delete(cache.keys().next().value);
    return value;
  }
  function decode(value) {
    if (!/[\u3400-\u9fff\ue000-\uf8ff]/u.test(value)) return value;
    const {font, chars} = fontData(), {Typr, md5} = root.MoocFontTools;
    return [...value].map(ch => {
      if (!/[\u3400-\u9fff\ue000-\uf8ff]/u.test(ch)) return ch;
      if (chars.has(ch)) return chars.get(ch);
      let glyph, path;
      try { glyph = Typr.U.codeToGlyph(font, ch.codePointAt(0)); if (glyph) path = Typr.U.glyphToPath(font, glyph); }
      catch { throw new Error('混淆字体字形解析失败，请手动处理当前测验'); }
      // A missing glyph is rendered by the browser's normal fallback font.
      if (!glyph) { chars.set(ch, ch); return ch; }
      const code = path?.cmds.length ? root.MoocGlyphTable[md5(JSON.stringify(path)).slice(24)] : null;
      if (!Number.isInteger(code) || code < 0x3400 || code > 0x9fff) throw new Error('本地字形表未覆盖当前混淆字体，已停止答题，请手动处理当前测验');
      const plain = String.fromCodePoint(code); chars.set(ch, plain); return plain;
    }).join('');
  }
  function encrypted(el) {
    return Boolean(el.closest('.font-cxsecret')) || /(?:^|[\s,"'])font-cxsecret(?:$|[\s,"'])/i.test(getComputedStyle(el).fontFamily);
  }
  function read(el) {
    if (!el) return '';
    if (!el.querySelector('.font-cxsecret') && !encrypted(el)) return (el.innerText ?? el.textContent ?? '').trim();
    const pieces = [];
    function walk(node) {
      if (node.nodeType === Node.TEXT_NODE) { pieces.push(encrypted(node.parentElement) ? decode(node.nodeValue) : node.nodeValue); return; }
      if (node.nodeType !== Node.ELEMENT_NODE || node.matches('script, style, [hidden]')) return;
      const css = getComputedStyle(node);
      if (css.display === 'none' || css.visibility === 'hidden') return;
      if (node.tagName === 'BR') { pieces.push('\n'); return; }
      const block = /^(block|flex|grid|list-item|table-row)$/.test(css.display);
      if (block) pieces.push('\n');
      for (const child of node.childNodes) walk(child);
      if (block) pieces.push('\n');
    }
    walk(el);
    return pieces.join('').trim();
  }
  root.MoocFontDecoder = {begin, read};
})(globalThis);

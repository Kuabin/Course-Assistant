'use strict';
const $ = id => document.getElementById(id);
let draft = null, currentBank = null, settings = {autoSubmit: true, backgroundPlayback: true, selectors: {}}, tabId;
let refreshing=false,refreshAgain=false;
function notice(message, error = false) { $('notice').textContent = message; $('notice').className = error ? 'error' : ''; }
function describeBank() {
  $('bankStatus').textContent = currentBank
    ? `当前题库：${currentBank.stats.total} 道题`
    : '尚未导入答案库';
}
async function control(action) {
  if (!tabId) throw new Error('请切换到学习通课程的学生学习页面，再打开扩展');
  if (action === 'start' || action === 'resume' || action === 'checkManual') {
    const info = await control('info');
    if (info.contentVersion !== chrome.runtime.getManifest().version) throw new Error('课程页面仍在使用旧脚本，请刷新整个课程页面后再开始');
  }
  const result = await chrome.runtime.sendMessage({mooc: true, command: 'POPUP_CONTROL', tabId, payload: {action}});
  if (!result?.ok) throw new Error(result?.error || '扩展无法连接，请刷新课程页面');
  if (!result.value?.ok) throw new Error(result.value?.error || '课程页面无法响应');
  return result.value;
}
async function refresh() {
  if (refreshing) {refreshAgain=true;return;}
  refreshing=true;
  try {
    const info = await control('info');
    const version = chrome.runtime.getManifest().version;
    if (info.contentVersion !== version) throw new Error('课程页面仍在使用旧脚本，请刷新整个课程页面后再开始');
    $('courseStatus').textContent = `${info.state.title || '当前章节'}\n${info.state.message}`;
    $('courseStatus').className=info.state.status==='done'?'complete':'';
    const running = info.state.status === 'running';
    document.querySelector('[data-action="start"]').disabled = running || Boolean(info.state.manual);
    document.querySelector('[data-action="stop"]').disabled = info.state.status === 'idle';
    $('checkManual').hidden = !info.state.manual;
    $('checkManual').disabled = info.state.status !== 'paused';
  } catch (error) {
    $('courseStatus').className='';
    $('courseStatus').textContent = error.message;
    document.querySelector('[data-action="start"]').disabled = true;
    $('checkManual').hidden = true;
    $('checkManual').disabled = true;
  } finally {
    refreshing=false;
    if (refreshAgain) {refreshAgain=false;void refresh();}
  }
}
function download(name, value) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], {type:'application/json;charset=utf-8'}));
  const link = document.createElement('a'); link.href = url; link.download = name;
  document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function showDraft() {
  if (!draft) { $('saveBank').disabled = true; $('cancelImport').disabled = true; return; }
  const preview = [`${draft.name}\n共 ${draft.stats.total} 道题`,
    '\n前 6 条预览：', ...draft.entries.slice(0, 6).map(e => `${e.chapter} · ${e.type}\n${e.stem}\n答案：${e.type === '判断题' ? (e.answer === true ? '对' : e.answer === false ? '错' : '无效') : e.answer}\n${e.answerTexts.join('；')}`),
    '\n解析异常及格式提示：', ...draft.issues.slice(0, 80).map(i => `第 ${i.line} 行 [${i.severity}] ${i.message}`)];
  if (draft.issues.length > 80) preview.push(`另有 ${draft.issues.length - 80} 条提示。`);
  $('preview').textContent = preview.join('\n');
  $('saveBank').disabled = draft.stats.usable === 0; $('cancelImport').disabled = false;
}
$('file').addEventListener('change', async event => {
  try {
    const file = event.target.files[0]; if (!file) return;
    if (file.size > 2 * 1024 * 1024) throw new Error('答案文件超过 2 MB，请拆分后导入');
    draft = MoocCore.parseMarkdown(await file.text(), file.name); showDraft();
    if (!draft.stats.total) throw new Error('未识别到题目。请使用“**1.【单选题】** 题干(B)”格式。');
    notice('请核对预览和行尾答案格式，再点击“确认导入”。异常条目不会用于自动答题。');
  } catch (error) { draft = null; showDraft(); notice(error.message, true); }
});
$('saveBank').addEventListener('click', async () => {
  try {
    if (!draft?.stats.usable) return;
    await chrome.storage.local.set({answerBank: draft}); currentBank = draft; draft = null; showDraft(); describeBank();
    notice('答案库已保存到本机。课程暂停后点击开始即可使用。'); await refresh();
  } catch (error) { notice(error.message, true); }
});
$('cancelImport').addEventListener('click', () => { draft = null; $('file').value = ''; $('preview').textContent = '已取消本次导入。'; showDraft(); });
for (const button of document.querySelectorAll('[data-action]')) button.addEventListener('click', async () => {
  try { await control(button.dataset.action); notice('状态已更新，请查看课程页面提示。'); await refresh(); }
  catch (error) { notice(error.message, true); }
});
$('checkManual').addEventListener('click', async () => {
  $('checkManual').disabled = true;
  try { await control('checkManual'); notice('已检查提交状态，请查看课程页面提示。'); }
  catch (error) { notice(error.message, true); }
  finally { await refresh(); }
});
async function saveSettings(reset = false) {
  const selectors = reset ? {} : JSON.parse($('selectors').value);
  if (!selectors || Array.isArray(selectors) || typeof selectors !== 'object') throw new Error('选择器设置必须是 JSON 对象');
  MoocAdapter.configure(selectors);
  const data = await chrome.storage.local.get('settings');
  settings = {...settings, ...data.settings, autoSubmit: $('autoSubmit').checked, backgroundPlayback: $('backgroundPlayback').checked, selectors};
  await chrome.storage.local.set({settings}); $('selectors').value = JSON.stringify(selectors, null, 2);
  notice('设置已保存；运行中的课程会暂停，点击开始后生效。'); await refresh();
}
$('saveSettings').addEventListener('click', () => saveSettings().catch(error => notice(error.message, true)));
$('defaultSettings').addEventListener('click', () => saveSettings(true).catch(error => notice(error.message, true)));
$('autoSubmit').addEventListener('change', async () => {
  try { await saveOption('autoSubmit', $('autoSubmit').checked); notice('提交设置已保存，点击开始重新检查。'); await refresh(); }
  catch (error) { notice(error.message, true); }
});
$('backgroundPlayback').addEventListener('change', async () => {
  try {
    await saveOption('backgroundPlayback', $('backgroundPlayback').checked);
    notice('后台运行设置已保存，回到课程点击开始；首次更新扩展后请刷新课程页。'); await refresh();
  } catch (error) { notice(error.message, true); }
});
async function saveOption(key, value) {
  const data = await chrome.storage.local.get('settings');
  settings = {...settings, ...data.settings, [key]: value};
  await chrome.storage.local.set({settings});
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.settings) {
    settings = {autoSubmit: true, backgroundPlayback: true, selectors: {}, ...changes.settings.newValue};
    $('autoSubmit').checked = settings.autoSubmit;
    $('backgroundPlayback').checked = settings.backgroundPlayback !== false;
  }
  if (changes.answerBank) { currentBank = MoocCore.resolveBank(changes.answerBank.newValue, MoocBuiltinBank); describeBank(); }
  if (changes.settings || changes.answerBank || Object.keys(changes).some(key=>key.startsWith('session:'))) void refresh();
});
$('diagnose').addEventListener('click', async () => {
  try { const result = await control('diagnose'); download('mooc-diagnostics.json', result.diagnostics); notice('诊断文件已导出；包含当前题目文字，请自行决定是否分享。'); }
  catch (error) { notice(error.message, true); }
});
$('resetAttempts').addEventListener('click', async () => {
  try { await control('resetAttempts'); notice('提交记录已重置。'); await refresh(); }
  catch (error) { notice(error.message, true); }
});
(async () => {
  const data = await chrome.storage.local.get(['answerBank', 'settings']);
  currentBank = MoocCore.resolveBank(data.answerBank, MoocBuiltinBank); settings = {...settings, ...data.settings}; describeBank();
  $('autoSubmit').checked = settings.autoSubmit; $('selectors').value = JSON.stringify(settings.selectors, null, 2);
  $('backgroundPlayback').checked = settings.backgroundPlayback !== false;
  $('defaults').textContent = JSON.stringify(MoocAdapter.defaults, null, 2);
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  tabId = tab?.id; await refresh();
  setInterval(()=>void refresh(),2000);
})().catch(error => notice(error.message, true));
